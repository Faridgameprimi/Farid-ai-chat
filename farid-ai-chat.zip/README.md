# Farid AI Chat
Frontend pakai Firebase Hosting + Auth + Firestore.  
Backend pakai Cloud Function `chatWithAI` untuk hubungi OpenAI.
## Deploy:
1. firebase deploy --only functions
2. firebase deploy --only hosting
